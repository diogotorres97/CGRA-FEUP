/**
 * MyCylinder
 * @constructor
 */
 function MyCylinder(scene, slices, stacks) {
 	CGFobject.call(this,scene);

	this.slices = slices;
	this.stacks = stacks;

 	this.initBuffers();
 };

 MyCylinder.prototype = Object.create(CGFobject.prototype);
 MyCylinder.prototype.constructor = MyCylinder;

 MyCylinder.prototype.initBuffers = function() {
 	/*
 	* TODO:
 	* Replace the following lines in order to build a prism with a **single mesh**.
 	*
 	* How can the vertices, indices and normals arrays be defined to
 	* build a prism with varying number of slices and stacks?
 	*/
	 ang = 0;
	 angnorm = Math.PI/this.slices;
	 z = 1; 
	 zdelta = z/this.stacks;
	 this.vertices = [];
	 this.normals = [];
	 this.indices = [];

	 for(i = 0; i<this.stacks; i++){
		ad_index = i*this.slices;

		if(i == 0){
			for(j = 0; j < this.slices; j++){
				ang = j*2*Math.PI/this.slices;

				this.vertices.push(Math.cos(ang), Math.sin(ang), i*zdelta);

				x1 = Math.cos(ang);
				y1 = Math.sin(ang);

				norma= Math.sqrt(x1*x1 + y1*y1);

				this.normals.push(x1/norma, y1/norma, 0);
			}
		}

		for(h = 0; h < this.slices; h++){
			ang = h*2*Math.PI/this.slices;

			this.vertices.push(Math.cos(ang), Math.sin(ang), (i+1)*zdelta);

			x1 = Math.cos(ang);
			y1 = Math.sin(ang);

			norma= Math.sqrt(x1*x1 + y1*y1);

			this.normals.push(x1/norma, y1/norma, 0);
		}


		for(k = 0; k < this.slices-1; k++){
			this.indices.push(k+ad_index, k+1+ad_index, k+this.slices+ad_index);
			this.indices.push(k+1+ad_index, k+this.slices+1+ad_index, k+this.slices+ad_index);
		}

		this.indices.push(this.slices-1+ad_index, ad_index, 2*this.slices-1+ad_index);
		this.indices.push(ad_index, this.slices+ad_index, 2*this.slices-1+ad_index);
	 }

	 /*
	 for(h = 0; h < 4*3*this.slices; h++){
		console.log(this.vertices[h]);
	 }
	 */

	 /*
	  for(h = 0; h < 6*(this.slices); h++){
		console.log(this.indices[h]);
	 }
	 */


 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();

 };
