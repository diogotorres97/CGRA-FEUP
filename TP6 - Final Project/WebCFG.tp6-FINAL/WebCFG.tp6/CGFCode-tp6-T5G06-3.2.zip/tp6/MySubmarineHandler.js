/**
* MySubmarineHandler
* @constructor
*/
function MySubmarineHandler(scene,posX, posY, posZ, angulo) {
	CGFobject.call(this,scene);

	this.submarine = new MySubmarine(this.scene);

	this.angs = angulo;
	this.posX = posX;
	this.posY = posY;
	this.posZ = posZ;



	this.delta = 0;
 	this.first = 0;
	this.lastCurrTime = 0;

};

MySubmarineHandler.prototype = Object.create(CGFobject.prototype);
MySubmarineHandler.prototype.constructor = MySubmarineHandler;

MySubmarineHandler.prototype.display = function() {

	this.scene.pushMatrix();
	this.scene.translate(this.posX, this.posY, this.posZ);
	this.scene.rotate(this.angs, 0, 1, 0);
	this.submarine.display();
	this.scene.popMatrix();


};

MySubmarineHandler.prototype.update = function(currTime) {

	this.submarine.update(currTime);

		this.delta = currTime - this.lastCurrTime;
		this.lastCurrTime = currTime;


		if (this.first == 0)
		{
			this.delta = 0;
			this.first = 1;
		}
};

MySubmarineHandler.prototype.setRotate = function(rotation) {
 	this.angs += rotation;

 };

 MySubmarineHandler.prototype.setTravel = function(travel) {
 	this.posX += travel* Math.sin(this.angs);
 	this.posZ += travel* Math.cos(this.angs);


 };
