/**
* MySubmarine
* @constructor
*/
function MySubmarine(scene) {
	CGFobject.call(this,scene);
	
	this.semiSphere = new MyLamp(this.scene,50,10);
	this.cylinder = new MyCylinder(this.scene,100,4);
	this.circle = new MyCircle(this.scene,100);
	this.cube = new MyUnitCubeQuad(this.scene);
	this.trap = new MyTrap(this.scene,0.75);
	this.propang = 45;
	this.angs = 0;
	this.framerate = 0;
	this.delta = 0;
	this.lastCurrTime = 0;
};

MySubmarine.prototype = Object.create(CGFobject.prototype);
MySubmarine.prototype.constructor = MySubmarine;

MySubmarine.prototype.display = function() {

	//Back
	this.scene.pushMatrix();
	this.scene.scale(0.365,0.5,0.47);
	this.scene.translate(0,0,1);
	this.scene.rotate(-180*degToRad,1,0,0);
	this.semiSphere.display();
	this.scene.popMatrix();

	//Main Body
	this.scene.pushMatrix();
	this.scene.translate(0,0,0.46);
	this.scene.scale(0.365,0.5,4.08);
	this.cylinder.display();
	this.scene.popMatrix();

	//Front
	this.scene.pushMatrix();
	this.scene.translate(0,0,4.53);
	this.scene.scale(0.365,0.5,0.47);
	this.semiSphere.display();
	this.scene.popMatrix();
	
	//Cockpit
	this.scene.pushMatrix();
	this.scene.translate(0,0,2.8);
	this.scene.rotate(-90*degToRad,1,0,0);
	this.scene.scale(0.365,0.44,1.07);
	this.cylinder.display();
	this.scene.popMatrix();
	
	//Cockpit Top
	this.scene.pushMatrix();
	this.scene.translate(0,1.07,2.8);
	this.scene.rotate(-90*degToRad,1,0,0);
	this.scene.scale(0.365,0.44,1);
	this.circle.display();
	this.scene.popMatrix();
	
	//Periscope Vert
	this.scene.pushMatrix();
	this.scene.translate(0,1.07,3.05);
	this.scene.rotate(-90*degToRad,1,0,0);
	this.scene.scale(0.05,0.05,0.57);
	this.cylinder.display();
	this.scene.popMatrix();
	
	//Periscope Hor
	this.scene.pushMatrix();
	this.scene.translate(0,1.63,3);
	this.scene.scale(0.05,0.05,0.2);
	this.cylinder.display();
	this.scene.popMatrix();
	
	//Periscope Cover
	this.scene.pushMatrix();
	this.scene.translate(0,1.63,3);
	this.scene.rotate(180*degToRad,0,1,0);
	this.scene.scale(0.05,0.05,0.2);
	this.circle.display();
	this.scene.popMatrix();
	
	//Left Propeller
	//Cylinder
	this.scene.pushMatrix();
	this.scene.translate(0.52,-0.225,0.48);
	this.scene.scale(0.2,0.2,0.15);
	this.cylinder.display();
	this.scene.popMatrix();
	
	//Front Cover
	this.scene.pushMatrix();
	this.scene.translate(0.52,-0.225,0.561);
	this.scene.scale(0.05,0.05,1);
	this.circle.display();
	this.scene.popMatrix();
	
	//Back Cover
	this.scene.pushMatrix();
	this.scene.translate(0.52,-0.225,0.549);
	this.scene.rotate(180*degToRad,1,0,0);
	this.scene.scale(0.05,0.05,1);
	this.circle.display();
	this.scene.popMatrix();
	
	//Blade
	this.scene.pushMatrix();
	this.scene.translate(0.52,-0.225,0.555);
	this.scene.rotate(this.propang*degToRad,0,0,1)
	this.scene.scale(0.375,0.09,0.01); 
	this.cube.display();
	this.scene.popMatrix();
	
	//Right Propeller
	//Cylinder
	this.scene.pushMatrix();
	this.scene.translate(-0.52,-0.225,0.48);
	this.scene.scale(0.2,0.2,0.15);
	this.cylinder.display();
	this.scene.popMatrix();
	
	//Front Cover
	this.scene.pushMatrix();
	this.scene.translate(-0.52,-0.225,0.561);
	this.scene.scale(0.05,0.05,1);
	this.circle.display();
	this.scene.popMatrix();
	
	//Back Cover
	this.scene.pushMatrix();
	this.scene.translate(-0.52,-0.225,0.549);
	this.scene.rotate(180*degToRad,1,0,0);
	this.scene.scale(0.05,0.05,1);
	this.circle.display();
	this.scene.popMatrix();
	
	//Blade
	this.scene.pushMatrix();
	this.scene.translate(-0.52,-0.225,0.555);
	this.scene.rotate(this.propang*degToRad,0,0,1)
	this.scene.scale(0.375,0.09,0.01); 
	this.cube.display();
	this.scene.popMatrix();
	
	
	//Vert Back Wing
	this.scene.pushMatrix();
	this.scene.translate(0,0,0.36);
	this.scene.rotate(-90*degToRad,0,1,0);
	this.scene.rotate(-90*degToRad,0,0,1);
	this.scene.scale(1.70,0.2,0.05); 
	this.trap.display();
	this.scene.popMatrix();
	
	//Hor Back Wing
	this.scene.pushMatrix();
	this.scene.translate(0,0,0.36);
	this.scene.rotate(90*degToRad,1,0,0);
	this.scene.scale(1.70,0.2,0.05); 
	this.trap.display();
	this.scene.popMatrix();
	
	//Hor Cockpit Wing
	this.scene.pushMatrix();
	this.scene.translate(0,0.785,2.8);
	this.scene.rotate(-90*degToRad,1,0,0);
	this.scene.scale(1.42,0.3,0.05);
	this.trap.display();
	this.scene.popMatrix();
};

MySubmarine.prototype.update = function(currTime) {

	if(this.stopped)
	return;

	this.delta = currTime - this.lastCurrTime;
	this.lastCurrTime = currTime;

	if (this.first == 0)
	{
		this.delta = 0;
		this.first = 1;
	}
	
	this.framerate = 1/(this.delta/1000);
	
	inc = this.angs/this.framerate;
	//console.log(inc);
	//console.log(this.propang);
	this.angs--;
 	this.propang += inc;
	if(Math.abs(this.propang) > 360)
		this.propang -= 360
};