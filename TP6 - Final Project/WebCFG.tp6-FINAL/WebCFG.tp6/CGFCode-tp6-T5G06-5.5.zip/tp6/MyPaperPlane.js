/**
 * MyClockHand
 * @constructor
 */
function MyPaperPlane(scene) {
	CGFobject.call(this,scene);

	this.wall = false;
	this.floor= false;
	this.first=0;
	this.delta=0;
	this.lastCurrTime = 0;
	this.framerate = 0;
	this.x = 0;
	this.y = 0;
	this.dx = 0.25;
	this.dy = 0.01;
	this.angx = 0;
	this.angy = 0;
	//	console.log("3");
	//	console.log(this.scene.getMatrix());

	this.initBuffers();
};

MyPaperPlane.prototype = Object.create(CGFobject.prototype);
MyPaperPlane.prototype.constructor = MyPaperPlane;

MyPaperPlane.prototype.initBuffers = function() {
	this.vertices = [
		0, 0, 1,
		-0.5, 0, 0,
		0.5, 0, 0,
		0, 0, 0,
		0, -0.5, 0,
		];

	this.indices = [
		0, 2, 1,
		0, 1, 2,
		0, 4, 3,
		0, 3, 4,
		];


	this.normals = [
		0, 1, 0,
		0, 1, 0,
		0, 1, 0,
		0, 0, 1,
		0, 0, 1,
		];

	this.primitiveType = this.scene.gl.TRIANGLES;
	this.initGLBuffers();
};


MyPaperPlane.prototype.display = function() {
	if(this.floor){
		CGFobject.prototype.display.call(this);
		return;
	}

	if(this.wall){
		this.scene.pushMatrix();
		this.scene.translate(0, this.y, this.x);
		this.scene.rotate(-this.angx*degToRad, 1,0,0);
		this.scene.rotate(-this.angy*degToRad, 0,1,0);
		CGFobject.prototype.display.call(this);
		this.scene.popMatrix();
		return;
	}

	this.scene.translate(0, this.y*this.y, this.x);
	this.scene.rotate(-this.angx*degToRad, 1,0,0);
	CGFobject.prototype.display.call(this);
};

MyPaperPlane.prototype.update = function(currTime) {

	this.delta = currTime - this.lastCurrTime;
	this.lastCurrTime = currTime;

	if (this.first == 0)
	{
		this.delta = 0;
		this.first = 1;
		return;
	}


	this.framerate = 1/(this.delta/1000);

	if(this.floor){
		return;
	}

	if(this.wall){
		this.dy = -4.55/(0.5*this.framerate);
		this.dx = -0.5/(0.5*this.framerate);
		dangx = -180/(0.5*this.framerate);
		dangy = -240/(0.5*this.framerate);

		this.x += this.dx;
		this.y += this.dy;
		this.angx += dangx;
		this.angy += dangy;

		if(this.y <= -4){
			//this.floor = true;
			this.wall = false;
			this.x = 0;
			this.y = 0;
			this.dx = 0.25;
			this.dy = 0.01;
			this.angx = 0;
			this.angy = 0;
		}

		return;
	}


	this.dy = 1/(2*this.framerate);
	this.dx = 6/(2*this.framerate);
	dang = 20/(10*this.framerate);

	this.x += this.dx;
	this.y += this.dy;
	this.angx += dang;
	if(this.x >= 6){
		this.wall = true;
	}
};
